#!/bin/bash
# Phase 3 Final — Step 6: Submit QPU job via qBraid
# Prerequisite: Run qpu_preflight.py first to check availability and cost
# Usage: bash scripts/phase3/06_submit_qpu.sh
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(cd "${SCRIPT_DIR}/../.." && pwd)"
cd "${ROOT}"

PYTHON="${PYTHON:-python}"
export PY="${PYTHON}"

OUT_DIR=results/phase3_final/qpu
mkdir -p "$OUT_DIR"

echo "=== Step 6: QPU submission ==="

# Step 6a: Preflight check
echo "[6a] Running QPU preflight..."
$PY scripts/qpu_preflight.py --dry-run --out "$OUT_DIR/preflight.json"

# Step 6b: Submit to QPU (or qBraid simulator if no QPU available)
echo ""
echo "[6b] Submitting best circuit to qBraid..."
$PY src/gqe/eval/submit_qpu.py \
    --benchmark results/phase3_final/benchmark_ch3i_consolidated.json \
    --config configs/phase3_final/qpu_validation.yaml \
    --device "${QPU_DEVICE:-qbraid:qbraid:sim:qir-sv}" \
    --shots "${QPU_SHOTS:-4096}" \
    --out "$OUT_DIR/qpu_submission.json"

echo ""
echo "=== QPU submission complete ==="
echo "Monitor job with: $PY src/gqe/eval/collect_qpu.py --job-id <ID>"
echo "Results: $OUT_DIR/"
