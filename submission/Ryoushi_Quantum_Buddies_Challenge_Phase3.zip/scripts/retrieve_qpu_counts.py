#!/usr/bin/env python3
"""Retrieve qBraid QPU job counts and save raw results.

Lightweight version of retrieve_and_sqd.py — just fetches counts,
no SQD post-processing or exact diagonalization.
"""
from __future__ import annotations

import json
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from qbraid.runtime import load_job


def retrieve_counts(job_id: str, max_retries: int = 6) -> dict | None:
    """Retrieve counts from a qBraid job with retry."""
    for attempt in range(max_retries):
        try:
            job = load_job(job_id)
            status = job.status()
            print(f"  Attempt {attempt+1}: {job_id} -> {status}")
            if "COMPLETED" in str(status).upper():
                result = job.result()
                try:
                    counts = result.data.get_counts()
                except Exception:
                    counts = result.measurement_counts()
                return {str(k): int(v) for k, v in counts.items()}
            elif "FAILED" in str(status).upper() or "CANCELLED" in str(status).upper():
                print(f"  Job {job_id} terminal status: {status}")
                return None
            else:
                time.sleep(10)
        except Exception as e:
            print(f"  Attempt {attempt+1} error: {e}")
            time.sleep(10 * (attempt + 1))
    return None


def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--meta", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()

    with open(args.meta) as f:
        meta = json.load(f)

    sqd_jobs = meta.get("sqd_jobs", {})
    all_results = {}

    for mol, job_id in sqd_jobs.items():
        if job_id is None:
            continue
        print(f"\n=== {mol} ===")
        counts = retrieve_counts(job_id)
        if counts:
            print(f"  Retrieved {len(counts)} bitstrings, {sum(counts.values())} total shots")
            all_results[mol] = {
                "status": "completed",
                "job_id": job_id,
                "counts": counts,
                "n_shots": sum(counts.values()),
                "n_unique": len(counts),
            }
        else:
            all_results[mol] = {"status": "pending", "job_id": job_id}

    args.out.parent.mkdir(parents=True, exist_ok=True)
    with open(args.out, "w") as f:
        json.dump(all_results, f, indent=2)
    print(f"\nResults saved: {args.out}")


if __name__ == "__main__":
    main()
